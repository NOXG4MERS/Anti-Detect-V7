local List0 = {false
}

local Keys = {false}



local AbnormalDataCheckTableBase = {false

    -- 记录数
	COUNT = 1,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = false,
	game_mod = 10,
	head_shot_rate = 1000,
	total_real_kill_num = 100,
	be_other_report = 100,
	avg_real_kill_num = 100,
	check_duration = 7000,

    -- 标识常量
}



return AbnormalDataCheckTableBase